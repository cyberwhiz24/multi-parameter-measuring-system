The sketches in this directory are intended to be checkin tests.
No code should be pushed to github without these tests passing.

See "runtests.sh" script inside each sketch dir.  This script is fully compatible with
git bisest.

Note that this requires python and py-serial
